Terimakasih sebelumnya sudah menggunakan template website ini!

Teknologi yang digunakan:
-  Bootstrap v5
-  HTML
-  CSS
-  Vanilla Javascript

Fitur:
-  Lazy Load
-  Filter

template website ini masih ada kekurangannya jadi jangan lupa support aku dengan follow akun Tiktok saya

=> Link: https://www.tiktok.com/@joudevcoy